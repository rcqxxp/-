
#ifndef PHONE_H
#define PHONE_H
#include <string>
#include <iostream>
#include <vector>
using namespace std;
class Phone {
public:
    string brand;
    string model;
    string processor;
    int storageGB;
    int ramGB;
    int price;

    Phone(string b, string m, string p, int s, int r, int pr);
    void display() const;

    static vector<Phone> filterPhones(const vector<Phone>& phones, int minPrice, int maxPrice,
        const string& processor, int minStorage, int minRAM);

    static void comparePhones(const Phone& p1, const Phone& p2);
};

#endif // PHONE_H
